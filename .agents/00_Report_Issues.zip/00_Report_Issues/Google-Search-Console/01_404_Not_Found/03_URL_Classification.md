# 03 - URL Classification

**Project:** SearchSarkariNaukri.com

**Module:** URL Classification for Google Search Console 404 URLs

**Priority:** 🔴 Critical

**Status:** Investigation

---

# Purpose

This document defines how every URL from the Google Search Console 404 report should be classified before any implementation begins.

The objective is to ensure every URL receives the correct resolution strategy.

This document is only for classification.

It does not include:

- Redirect implementation
- Route changes
- Database changes
- UI changes
- Content changes
- SEO improvements

Those are handled in later documents.

---

# Reference File

Google Search Console Export

```
https___www.searchsarkarinaukri.com_-Coverage-Drilldown-2026-08-05.xlsx
```

This Excel file contains all **607 URLs** reported under

Google Search Console

↓

Page Indexing

↓

Not Found (404)

Every URL must be classified.

---

# Objective

The goal is to place every affected URL into exactly one category.

No URL should belong to multiple categories.

After classification, developers can decide the correct action in later implementation documents.

---

# Classification Workflow

```
Google Search Console Report

↓

Read URL

↓

Identify URL Structure

↓

Identify URL Type

↓

Assign Category

↓

Assign Priority

↓

Continue to Database Verification
```

---

# Classification Rules

Every URL must be classified into one of the following categories.

---

# Category A — Active Job URL

Description

The job still exists and should remain available.

Example

```
/jobs/staff-selection-commission-ssc-je-2026-855
```

Expected Status

```
HTTP 200
```

Developer Action

No action in this document.

Mark as

```
Active Job
```

Continue to Database Verification.

---

# Category B — Legacy Numeric URL

Description

Old numeric URLs without SEO-friendly slugs.

Example

```
/jobs/855

/jobs/1108

/jobs/1455
```

Possible Cause

- Previous URL structure
- Old routing
- Missing redirect

Mark as

```
Legacy Numeric URL
```

---

# Category C — SEO Slug URL

Description

SEO-friendly URLs.

Example

```
/jobs/barc-technical-officer-855

/jobs/uidai-recruitment-2026
```

Possible Cause

- Slug changed
- Record removed
- Route mismatch

Mark as

```
SEO Slug URL
```

---

# Category D — Archived Recruitment

Description

Government recruitment that has ended but still has historical SEO value.

Examples

```
SSC

UPSC

BARC

IBPS

Railway

NTPC

MPSC
```

These pages should be investigated for archive eligibility.

Mark as

```
Archived Recruitment
```

---

# Category E — Category Pages

Example

```
/category/bank-jobs

/category/state-government-jobs
```

Mark as

```
Category Page
```

---

# Category F — State Pages

Example

```
/states/maharashtra

/states/gujarat
```

Mark as

```
State Page
```

---

# Category G — District Pages

Example

```
/districts/pune

/districts/mumbai
```

Mark as

```
District Page
```

---

# Category H — City Pages

Example

```
/jobs-in-pune

/jobs-in-solapur
```

Mark as

```
City Page
```

---

# Category I — Permanently Deleted URL

Description

Page no longer exists.

No replacement.

No historical value.

Mark as

```
Deleted
```

---

# Category J — Unknown

Description

Unable to classify.

Requires manual investigation.

Mark as

```
Unknown
```

---

# Classification Checklist

For every URL record

| Field                  | Required |
| ---------------------- | -------- |
| Original URL           | ✅       |
| URL Pattern            | ✅       |
| Category               | ✅       |
| Priority               | ✅       |
| Investigation Required | ✅       |
| Notes                  | ✅       |

---

# Priority Levels

## Critical

- Job URLs
- Archived Recruitments
- High Traffic URLs

---

## High

- Category Pages
- State Pages
- District Pages
- City Pages

---

## Medium

- Unknown URLs

---

## Low

- Permanently Deleted URLs

---

# Rules

During classification

DO

- Read every URL.
- Compare similar URLs.
- Group similar patterns.
- Record observations.

DO NOT

- Modify routes.
- Create redirects.
- Restore pages.
- Delete pages.
- Change UI.
- Change frontend components.
- Modify page layout.
- Update content.
- Change metadata.
- Change database records.
- Modify business logic.

This document is strictly for URL classification.

---

# Expected Output

After completing this document every URL should have

- Category
- URL Type
- Priority
- Investigation Status

Nothing else.

No implementation should occur during this stage.

---

# Use Case

This document is used by

- SEO Team
- Developers
- QA Team

Purpose

To ensure every reported URL follows the correct investigation path before implementation begins.

---

# Success Criteria

The classification stage is complete when

- All 607 URLs have been reviewed.
- Every URL has exactly one category.
- Unknown URLs are documented separately.
- No implementation has been performed.
- The team is ready to begin Database Verification.

---

# Important Developer Instruction

This document is **analysis only**.

Do **not**:

- Change UI
- Change layout
- Change design
- Change page content
- Modify frontend components
- Modify backend business logic
- Create redirects
- Update database records

Only classify URLs.

Implementation begins in the next document.

---

# Next Document

```
04_Database_Verification.md
```

Purpose:

Verify whether each classified URL still exists in the database and determine whether it should be restored, archived, redirected, or permanently removed.

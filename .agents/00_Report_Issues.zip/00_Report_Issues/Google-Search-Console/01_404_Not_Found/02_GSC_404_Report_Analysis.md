# 02 - Google Search Console 404 Report Analysis

**Project:** SearchSarkariNaukri.com

**Module:** Google Search Console → Page Indexing → Not Found (404)

**Priority:** 🔴 Critical

**Status:** Investigation

---

# Purpose

This document analyzes the **Google Search Console 404 report** before any development work begins.

Its purpose is to understand:

- Which URLs are affected
- What types of URLs are failing
- Why they are failing
- Which URLs should be fixed
- Which URLs should remain removed

This document is **analysis only**.

It does **not** contain implementation steps.

Implementation is covered in later documents.

---

# Primary Objective

Analyze every URL reported in the Google Search Console export and classify the problem before making any code changes.

The objective is to prevent incorrect fixes such as:

- Restoring pages that should remain deleted
- Redirecting pages to unrelated destinations
- Creating unnecessary redirects
- Accidentally restoring duplicate URLs

---

# Reference Files

Use the following files throughout the analysis.

## Google Search Console Export

```
https___www.searchsarkarinaukri.com_-Coverage-Drilldown-2026-08-05.xlsx
```

This Excel file contains all **607 affected URLs**.

Every reported URL should be reviewed during this analysis.

---

# Scope

This document only analyzes the Google Search Console report.

Included

- URL review
- URL patterns
- URL counts
- URL types
- Common problems
- Investigation findings
- Classification preparation

Excluded

- Code changes
- Redirect implementation
- Database updates
- Sitemap changes
- Internal link fixes

Those topics are covered in later documents.

---

# Input

Google Search Console

↓

Page Indexing

↓

Not Found (404)

↓

607 URLs

---

# Expected Output

After completing this document, the development team should know

- What types of URLs exist
- Which URL structures are affected
- Which URLs require further investigation
- Which documents should be followed next

---

# Analysis Process

The recommended investigation process is

```
Google Search Console Report

↓

Open Excel Export

↓

Review URLs

↓

Identify URL Pattern

↓

Group Similar URLs

↓

Count Each Pattern

↓

Identify Possible Cause

↓

Prepare Classification

↓

Continue to URL Classification
```

---

# URL Pattern Analysis

During analysis, identify URL patterns such as

## Numeric URLs

Example

```
/jobs/855

/jobs/1108

/jobs/1455
```

Possible meaning

- Legacy URLs
- Old routing
- Missing redirect

---

## SEO Slug URLs

Example

```
/jobs/bhabha-atomic-research-centre-technical-officer-855

/jobs/uidai-recruitment-2026

/jobs/uco-bank-probationary-officer
```

Possible meaning

- Slug changed
- Deleted record
- Route issue

---

## Archived Recruitment Pages

Example

```
SSC

UPSC

BARC

Railway

IBPS

NTPC
```

Possible meaning

- Recruitment expired
- Page removed instead of archived

---

## Category URLs

Example

```
/category/bank-jobs
```

Possible meaning

- Category removed
- Incorrect route

---

## State URLs

Example

```
/states/maharashtra
```

Possible meaning

- Missing page
- Incorrect slug

---

## District URLs

Example

```
/districts/pune
```

Possible meaning

- Missing route
- Deleted page

---

## City URLs

Example

```
/jobs-in-pune
```

Possible meaning

- Dynamic page removed
- Incorrect routing

---

# Investigation Checklist

For every URL determine

- URL Pattern
- URL Type
- URL Structure
- Possible Cause
- Priority
- Next Investigation Step

---

# Expected Findings

Typical findings may include

- Legacy numeric URLs
- Old slug URLs
- Archived jobs removed
- Incorrect internal links
- Sitemap containing old URLs
- URL structure changes
- Duplicate URLs
- Permanently deleted pages

---

# Deliverables

At the end of this analysis the following information should be available.

- Total affected URLs
- URL pattern groups
- URL type summary
- Investigation notes
- Priority list
- Classification preparation

---

# Developer Notes

During this phase

Do

- Review URLs
- Compare similar URLs
- Document findings

Do Not

- Create redirects
- Modify routes
- Change code
- Restore pages
- Remove pages

This document is for analysis only.

---

# Use Case

This document is used

Before

- Database verification
- Redirect planning
- Route implementation

It provides the foundation for all remaining documentation.

Without this analysis, incorrect fixes may be implemented.

---

# Output of This Document

After completing this document, the team should understand

✅ What URLs are affected

✅ What URL patterns exist

✅ Which URL groups require investigation

✅ Which URLs should move to the next phase

The next step is to classify every affected URL.

---

# Next Document

```
03_URL_Classification.md
```

This document classifies every URL into logical groups and determines the appropriate resolution strategy for each type before implementation begins.

# 05 - URL Mapping

**Project:** SearchSarkariNaukri.com

**Module:** URL Mapping for Google Search Console 404 URLs

**Priority:** 🔴 Critical

**Status:** Planning

---

# Purpose

This document defines the final mapping for every URL reported under **Google Search Console → Page Indexing → Not Found (404)**.

After completing:

- URL Classification
- Database Verification

every URL should receive its final implementation action.

This document becomes the **master implementation reference** for developers.

---

# Reference File

Google Search Console Export

```
https___www.searchsarkarinaukri.com_-Coverage-Drilldown-2026-08-05.xlsx
```

This file contains all **607 affected URLs**.

Every URL must appear in the final mapping.

---

# Objective

The objective is to create a one-to-one mapping between

```
Current URL

↓

Required Action

↓

Final URL

↓

Expected HTTP Status
```

No implementation should occur during this stage.

---

# Scope

Included

- URL mapping
- Target URL selection
- Final HTTP status
- Priority assignment
- Developer notes

Excluded

- Redirect implementation
- Route changes
- Database updates
- UI changes
- Content changes
- Sitemap updates
- Internal link fixes

Those are implemented in later documents.

---

# Mapping Workflow

```
Google Search Console Report

↓

Database Verification

↓

Determine Final URL

↓

Determine HTTP Response

↓

Assign Priority

↓

Document Mapping

↓

Developer Implementation
```

---

# Mapping Rules

Every URL must have one final action.

No URL should remain without a decision.

---

## Action 1

### Keep Existing Page

Condition

- Page exists
- Correct URL
- No changes required

Result

```
HTTP 200
```

---

## Action 2

### Redirect

Condition

- URL changed
- Slug changed
- Legacy URL
- Numeric URL

Result

```
HTTP 301
```

---

## Action 3

### Archive

Condition

- Recruitment closed
- Historical value exists

Result

```
HTTP 200
```

---

## Action 4

### Permanently Removed

Condition

- No replacement
- No archive
- No SEO value

Result

```
HTTP 410
```

---

# Mapping Table

Every URL should contain the following information.

| Field               | Required |
| ------------------- | -------- |
| Original URL        | ✅       |
| URL Type            | ✅       |
| Verification Result | ✅       |
| Target URL          | ✅       |
| Final HTTP Status   | ✅       |
| Priority            | ✅       |
| Developer Status    | ✅       |
| QA Status           | ✅       |
| Notes               | ✅       |

---

# Example Mapping

| Original URL      | Target URL                                       | HTTP | Action   |
| ----------------- | ------------------------------------------------ | ---- | -------- |
| /jobs/855         | /jobs/staff-selection-commission-ssc-je-2026-855 | 301  | Redirect |
| /jobs/1108        | /jobs/railway-recruitment-board-1108             | 301  | Redirect |
| /jobs/ssc-je-2025 | Same URL                                         | 200  | Archive  |
| /jobs/999999      | None                                             | 410  | Remove   |

---

# Priority Levels

## Critical

- Active Jobs
- High Traffic Pages
- Indexed Pages
- Pages with backlinks

---

## High

- Archived Jobs
- Legacy URLs
- SEO Slugs

---

## Medium

- Category Pages
- State Pages
- District Pages
- City Pages

---

## Low

- Permanently Deleted Pages

---

# Mapping Validation

Before implementation verify

- Target URL exists.
- No duplicate mappings.
- No redirect loops.
- No redirect chains.
- Only one final destination.
- Correct HTTP status selected.

---

# Mapping Checklist

Every URL must have

- Original URL
- Final URL
- HTTP Status
- Verification Result
- Priority
- Implementation Status

---

# Rules

During mapping

DO

- Create one final mapping.
- Verify destination URLs.
- Record implementation notes.

DO NOT

- Implement redirects.
- Modify routes.
- Update database.
- Modify UI.
- Modify frontend.
- Modify backend logic.
- Change metadata.
- Change sitemap.

This document is only the implementation plan.

---

# Developer Instructions

This document is the primary reference during implementation.

Developers should use this mapping when implementing:

- Redirects
- Archive pages
- Permanent removals

Do not create additional mappings outside this document.

---

# Use Case

This document ensures

- Every URL has one final destination.
- Developers follow a consistent implementation plan.
- QA can verify expected behavior.
- Google Search Console validation matches implemented changes.

---

# Success Criteria

The mapping phase is complete when

- All **607 URLs** have been mapped.
- Every URL has one implementation action.
- No duplicate mappings exist.
- No URL is left undecided.
- The document is ready for implementation.

---

# Important Developer Notes

This document is **planning only**.

Do **not**

- Modify UI
- Modify layout
- Change page content
- Change frontend components
- Change backend business logic
- Update database
- Create redirects yet

Only prepare the final implementation mapping.

Implementation begins in the next document.

---

# Next Document

```
06_Redirect_Strategy.md
```

Purpose

This document defines how developers should implement:

- HTTP 301 Permanent Redirects
- HTTP 410 Gone responses
- Legacy URL handling
- Redirect priority
- Redirect validation

without changing the application's UI, existing content, business logic, or unrelated functionality.
